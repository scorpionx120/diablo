Hail Hitler
