<p align="center"><a href="https://t.me/fridayot"><img src="https://telegra.ph/file/22535f8051a58af113586.jpg" width="5000"></a></p> 
<h1 align="center"><b>FRIDAY-USERBOT 🇮🇳 </b></h1>
<h4 align="center">A Powerful, Smart And Simple Userbot In Telethon. Powered By NoSpam+</h4>







# Support
<a href="https://t.me/FridaySupportOfficial"><img src="https://img.shields.io/badge/Join-Telegram%20Channel-red.svg?logo=Telegram"></a>
<a href="https://t.me/fridayOT"><img src="https://img.shields.io/badge/Join-Telegram%20Group-blue.svg?logo=telegram"></a>


# Method
<a href="https://youtu.be/xfHcm_e92eQ"><img src="https://img.shields.io/badge/How%20To-Deploy-red.svg?logo=Youtube"></a>
<a href="https://app.gitbook.com/@starkgangz/s/fridayuserbot/"><img src="https://img.shields.io/badge/Read%20More-GitBook-red.svg"></a>



# KeyFeatures
* Multiple Client Support.
* AssistantBot Support.
* Channel Sticker / Post Appender / Night Mode / Amazon Price Tracker / Server Pinger Support.
* Yet Fast - Powered By FastTelethon.
* Smart & Powerful Tools.
* Customizable.
* Much Cleaner And Stable.
* Daily Maintained.
* NoSpam+ Support.

# String Session - Telethon
## Repl
[![Run on Repl.it](https://repl.it/badge/github/STARKGANG/friday)](https://friday.midhunkm1294.repl.run)

# Deploying To Heroku

[![Deploy To Heroku](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/DevsExpo/FridayUserbot)

# Self-hosting (For Devs)

### If You Want Modules Like Image / Vid Tools To Work You Need To Install These:
```
$ ffmpeg
$ Open CV
$ Chrome Driver
$ Chrome
$ gifsicle
$ mediainfo
```

## Simply clone the repository and run the main file:
```sh
# Install Git First // (Else You Can Download And Upload to Your Local Server)
$ git clone https://github.com/DevsExpo/FridayUserbot
# Open Git Cloned File
$ cd FridayUserbot
# Config Virtual Env (Skip is already Done.)
$ virtualenv -p /usr/bin/python3 venv
$ . ./venv/bin/activate
# Install All Requirements 
$ pip(3) install -r requirements.txt
# Create local.env with variables as given below
# Start Bot 
$ python(3) -m fridaybot
```

# Mandatory Configs
```
[+] Make Sure You Add All These Mandatory Vars. 
    [-] APP_ID:   You can get this value from https://my.telegram.org
    [-] API_HASH :   You can get this value from https://my.telegram.org
    [-] STRING_SESSION : Your String Session, You can get this From Repl or BY running StringGen File Locally
    [-] TG_BOT_TOKEN_BF_HER : Your Bot Token Obtained From @BotFather 
    [-] PRIVATE_GROUP_ID : Id of group where you wanna log important logs, Private group is recommended for this
    [-] DATABASE_URL: Data Base Url, You Can Make You Own By Following This Tutorial - https://www.digitalocean.com/community/tutorials/how-to-install-and-use-postgresql-on-ubuntu-18-04, Else Get this from Elephant Sql, Or You can even make a heroku app to get Free DataBase.
[+] The fridayUserbot will not work without setting the mandatory vars.
```


## An Example Of "local.env" File.
```
APP_ID=2877510
API_HASH="fb6e6a1d96f3e6ea1b8e293912bd2edf"
STRING_SESSION="1AZWarzkBu6awXELYNW1w9xUMBt4OKtuOyMXX50ut5fUZ0oMo-0Qcp-GPDDc6YomgR7YdIL4woqQPHxpIvq6AXfPVbSeMN4nj_89Y03NSuDcEVOMhuJkfA6tTVUVPlkh4cQDgIwygG9GUYCAyntL4OvDIjLjNpkI68aSIrB9xChqa6T4uqn74AgRoUvN_5SQ0Y5F2Z6fz7UluwC33j0TuPMOWAdrcSooiIcjxe3WKtao6xz6-dWd0085sND8liyAdDrSQymzSC98kXx1Evo2GJG9matA6aGEyxNW_awuKB5Djjm6wkLszuYVuc03oeD9WNlyFtA-d_bd9Ge-TIScItpkiM8r4CCo="
TG_BOT_TOKEN_BF_HER="1651787609:AAFT8tyKb_h1kSS7zFLJ8Uqx3wmesqIUjls"
PRIVATE_GROUP_ID=-100535552668
DATABASE_URL="postgres://jchzxwhkwuhbldjnxqfp:142.compute1.amazonaws.com:5432/d14c1pas7r1clf"
```


# Licence
[![GNU GPLv3 Image](https://www.gnu.org/graphics/gplv3-127x51.png)](http://www.gnu.org/licenses/gpl-3.0.en.html)  

FridayUserbot is Free Software: You can use, study share and improve it at your
will. Specifically you can redistribute and/or modify it under the terms of the
[GNU General Public License](https://www.gnu.org/licenses/gpl.html) as
published by the Free Software Foundation, either version 3 of the License, or
(at your option) any later version. 

# Credits

* [@Chsaiujwal](https://telegram.dog/Chsaiujwal)
* [@Meisnub](https://telegram.dog/MeisNub)
* [@InukaAsith](https://telegram.dog/InukaAsith)
* [@Midhun_xD](https://telegram.dog/Midhun_xD)
* [@SpecHide](https://telegram.dog/SpecHide)
* [@S_n_a_p_s](https://telegram.dog/s_n_a_p_s)
* [@RaphielScape](https://github.com/raphielscape)
* [@Nitin1818](https://github.com/Nitin1818)
* [@PureIndiaLover](https://telegram.dog/PureIndiaLover)
* [@BLUE-DEVIL1134](https://github.com/BLUE-DEVIL1134)
